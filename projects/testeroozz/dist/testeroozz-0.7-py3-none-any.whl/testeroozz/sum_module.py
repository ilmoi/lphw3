"""This is a simplez testeroozz module. Does naffin useful."""

import random

class Summation(object):

    def great_summation(first, second):
        print("let's play a game")
        print("give me two numbers ill give you their sum")
        # first = input("first number: ")
        # second = input("second number: ")
        print(random.randint(1, 100))
        print("fuck you.")

simple_string = "it workalolololo!"

print('print statement inside sum_module')
