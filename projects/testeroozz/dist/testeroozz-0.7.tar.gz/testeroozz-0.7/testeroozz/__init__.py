from testeroozz.sum_module import *
print('print statement inside init')
